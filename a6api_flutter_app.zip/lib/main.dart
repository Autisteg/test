import 'package:flutter/material.dart';
import 'models/model_price.dart';
import 'pages/login_page.dart';
import 'pages/model_preview_page.dart';
import 'pages/price_monitor_page.dart';
import 'services/a6api_service.dart';
import 'services/price_history_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const A6ApiMonitorApp());
}

class A6ApiMonitorApp extends StatelessWidget {
  const A6ApiMonitorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'A6API 价格与预览',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E5EFF),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4D82FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final A6ApiService _apiService = A6ApiService();
  final PriceHistoryService _historyService = PriceHistoryService();

  int _currentIndex = 0;
  bool _initialized = false;
  List<ModelPrice> _models = [];
  String? _selectedPreviewModel;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _apiService.loadCredentials();
    final fetched = await _apiService.fetchModelsAndPrices();
    final merged = await _historyService.mergeWithHistoryAndSave(fetched);
    if (!mounted) return;
    setState(() {
      _models = merged;
      if (merged.isNotEmpty) {
        _selectedPreviewModel = merged.first.id;
      }
      _initialized = true;
    });
  }

  Future<void> _refreshPrices() async {
    final fetched = await _apiService.fetchModelsAndPrices();
    final merged = await _historyService.mergeWithHistoryAndSave(fetched);
    if (!mounted) return;
    setState(() {
      _models = merged;
      if (_selectedPreviewModel == null && merged.isNotEmpty) {
        _selectedPreviewModel = merged.first.id;
      }
    });
  }

  void _openModelPreview(String modelId) {
    setState(() {
      _selectedPreviewModel = modelId;
      _currentIndex = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      PriceMonitorPage(
        models: _models,
        historyService: _historyService,
        onRefresh: _refreshPrices,
        onPreviewModel: _openModelPreview,
      ),
      ModelPreviewPage(
        apiService: _apiService,
        models: _models.map((e) => e.id).toList(),
        initialModel: _selectedPreviewModel,
        onNeedLogin: () => setState(() => _currentIndex = 2),
      ),
      LoginPage(
        apiService: _apiService,
        onAuthChanged: _refreshPrices,
      ),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.trending_up_outlined),
            selectedIcon: Icon(Icons.trending_up),
            label: '价格变化',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: '模型预览',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: '账号登录',
          ),
        ],
      ),
    );
  }
}
