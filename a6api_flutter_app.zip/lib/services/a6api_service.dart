import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/model_price.dart';

class A6ApiService {
  static const defaultWebUrl = 'https://a6api.vip';
  static const defaultApiBaseUrl = 'https://api.a6api.vip/v1';

  static const _prefApiKey = 'a6api_key';
  static const _prefBaseUrl = 'a6api_base_url';
  static const _prefCookie = 'a6api_web_cookie';
  static const _prefUsername = 'a6api_username';

  String apiKey = '';
  String baseUrl = defaultApiBaseUrl;
  String webCookie = '';
  String username = '';

  Future<void> loadCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    apiKey = prefs.getString(_prefApiKey) ?? '';
    baseUrl = prefs.getString(_prefBaseUrl) ?? defaultApiBaseUrl;
    webCookie = prefs.getString(_prefCookie) ?? '';
    username = prefs.getString(_prefUsername) ?? '';
  }

  Future<void> saveCredentials({
    String? newApiKey,
    String? newBaseUrl,
    String? newCookie,
    String? newUsername,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    if (newApiKey != null) {
      apiKey = newApiKey.trim();
      await prefs.setString(_prefApiKey, apiKey);
    }
    if (newBaseUrl != null && newBaseUrl.trim().isNotEmpty) {
      baseUrl = newBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
      await prefs.setString(_prefBaseUrl, baseUrl);
    }
    if (newCookie != null) {
      webCookie = newCookie.trim();
      await prefs.setString(_prefCookie, webCookie);
    }
    if (newUsername != null) {
      username = newUsername.trim();
      await prefs.setString(_prefUsername, username);
    }
  }

  Future<void> clearCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefApiKey);
    await prefs.remove(_prefCookie);
    await prefs.remove(_prefUsername);
    apiKey = '';
    webCookie = '';
    username = '';
  }

  bool get isLoggedIn => apiKey.isNotEmpty || webCookie.isNotEmpty;

  /// 尝试通过帐号密码接口登录 a6api.vip（若站点启用了人机验证，可改用页面内的 WebView 登录）
  Future<({bool ok, String message})> loginWithPassword({
    required String account,
    required String password,
  }) async {
    try {
      final uri = Uri.parse('$defaultWebUrl/api/user/login');
      final resp = await http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode({
              'username': account.trim(),
              'password': password,
            }),
          )
          .timeout(const Duration(seconds: 15));

      final setCookie = resp.headers['set-cookie'] ?? '';
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        if (data is Map && (data['success'] == true || data['code'] == 0 || data['data'] != null)) {
          await saveCredentials(
            newCookie: setCookie.isNotEmpty ? setCookie : webCookie,
            newUsername: account.trim(),
          );
          return (ok: true, message: '登录成功');
        }
        final msg = (data is Map ? data['message'] : null)?.toString() ?? '登录失败';
        return (ok: false, message: msg);
      }
      return (ok: false, message: 'HTTP ${resp.statusCode}：请尝试使用内置网页登录');
    } catch (e) {
      return (ok: false, message: '直连登录异常，建议使用内置网页登录 ($e)');
    }
  }

  /// 获取模型列表与价格：
  /// 1. 优先尝试抓取/请求 a6api.vip 公开价格数据或用户控制台接口
  /// 2. 同时支持通过 /v1/models 补充可用模型列表
  Future<List<ModelPrice>> fetchModelsAndPrices() async {
    final now = DateTime.now();
    final results = <String, ModelPrice>{};

    // 1) 尝试请求标准定价接口（若携带 Cookie 则可读取登录态价格）
    final headers = <String, String>{
      'Accept': 'application/json',
      if (webCookie.isNotEmpty) 'Cookie': webCookie,
      if (apiKey.isNotEmpty) 'Authorization': 'Bearer $apiKey',
    };

    for (final endpoint in [
      '$defaultWebUrl/api/pricing',
      '$defaultWebUrl/api/marketplace/models',
    ]) {
      try {
        final resp = await http
            .get(Uri.parse(endpoint), headers: headers)
            .timeout(const Duration(seconds: 12));
        if (resp.statusCode == 200 && resp.body.trim().startsWith('{')) {
          final json = jsonDecode(resp.body) as Map<String, dynamic>;
          final list = (json['data'] ?? json['models']) as List<dynamic>?;
          if (list != null) {
            for (final item in list) {
              if (item is Map<String, dynamic>) {
                final id = (item['model_name'] ?? item['id'] ?? item['name'] ?? '').toString();
                if (id.isEmpty) continue;
                final price = (item['model_ratio'] ?? item['price'] ?? item['bottom_price'] ?? 0);
                results[id] = ModelPrice(
                  id: id,
                  vendor: (item['vendor'] ?? item['owned_by'] ?? _inferVendor(id)).toString(),
                  pricePerMillion: (price is num) ? price.toDouble() : double.tryParse(price.toString()) ?? 0,
                  channels: (item['channels'] as num?)?.toInt() ?? 0,
                  updatedAt: now,
                );
              }
            }
          }
        }
      } catch (_) {
        // 忽略单个探测端点失败，继续回退策略
      }
    }

    // 2) 若配置了 API Key，调用 OpenAI 兼容端点 /v1/models 获取最新可用模型
    if (apiKey.isNotEmpty) {
      try {
        final resp = await http
            .get(
              Uri.parse('$baseUrl/models'),
              headers: {'Authorization': 'Bearer $apiKey'},
            )
            .timeout(const Duration(seconds: 12));
        if (resp.statusCode == 200) {
          final json = jsonDecode(resp.body) as Map<String, dynamic>;
          final list = (json['data'] as List<dynamic>?) ?? [];
          for (final item in list) {
            if (item is Map<String, dynamic>) {
              final id = (item['id'] ?? '').toString();
              if (id.isEmpty) continue;
              results.putIfAbsent(
                id,
                () => ModelPrice(
                  id: id,
                  vendor: (item['owned_by'] ?? _inferVendor(id)).toString(),
                  pricePerMillion: 0,
                  channels: 1,
                  updatedAt: now,
                ),
              );
            }
          }
        }
      } catch (_) {}
    }

    // 3) 若尚未获取到线上结构化数据，提供从 a6api.vip 首页收录的基准参考价格作为初始兜底
    if (results.isEmpty) {
      for (final m in _fallbackShowcaseModels(now)) {
        results[m.id] = m;
      }
    }

    final list = results.values.toList()
      ..sort((a, b) => a.id.compareTo(b.id));
    return list;
  }

  /// 在线流式预览模型效果 (OpenAI SSE Chat Completions)
  Stream<({String delta, int? ttftMs, int? totalMs})> streamChatPreview({
    required String model,
    required String systemPrompt,
    required List<ChatMessage> history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) async* {
    if (apiKey.isEmpty) {
      throw StateError('请先在「登录」页配置或获取 A6API 的 API Key（sk-...）');
    }

    final messages = <Map<String, String>>[
      if (systemPrompt.trim().isNotEmpty)
        {'role': 'system', 'content': systemPrompt.trim()},
      for (final msg in history)
        if (!msg.isError && msg.content.trim().isNotEmpty)
          {'role': msg.role, 'content': msg.content},
    ];

    final request = http.Request(
      'POST',
      Uri.parse('$baseUrl/chat/completions'),
    );
    request.headers.addAll({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',
      'Accept': 'text/event-stream',
    });
    request.body = jsonEncode({
      'model': model,
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    });

    final stopwatch = Stopwatch()..start();
    int? firstTokenMs;

    final client = http.Client();
    try {
      final streamedResponse =
          await client.send(request).timeout(const Duration(seconds: 30));

      if (streamedResponse.statusCode != 200) {
        final errBody = await streamedResponse.stream.bytesToString();
        throw StateError('请求失败 (${streamedResponse.statusCode}): $errBody');
      }

      final lineStream = streamedResponse.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter());

      await for (final line in lineStream) {
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload == '[DONE]') break;
        try {
          final json = jsonDecode(payload) as Map<String, dynamic>;
          final choices = json['choices'] as List<dynamic>?;
          if (choices != null && choices.isNotEmpty) {
            final delta = (choices.first as Map<String, dynamic>)['delta']
                as Map<String, dynamic>?;
            final content = delta?['content']?.toString();
            if (content != null && content.isNotEmpty) {
              firstTokenMs ??= stopwatch.elapsedMilliseconds;
              yield (delta: content, ttftMs: firstTokenMs, totalMs: null);
            }
          }
        } catch (_) {
          // 跳过非 JSON 心跳行
        }
      }
      stopwatch.stop();
      yield (
        delta: '',
        ttftMs: firstTokenMs,
        totalMs: stopwatch.elapsedMilliseconds,
      );
    } finally {
      client.close();
    }
  }

  String _inferVendor(String id) {
    final lower = id.toLowerCase();
    if (lower.contains('gpt') || lower.contains('o1') || lower.contains('o3')) {
      return 'OpenAI';
    }
    if (lower.contains('claude')) return 'Anthropic';
    if (lower.contains('gemini')) return 'Google';
    if (lower.contains('deepseek')) return 'DeepSeek';
    if (lower.contains('glm')) return 'Zhipu';
    if (lower.contains('kimi')) return 'Moonshot';
    return 'Other';
  }

  List<ModelPrice> _fallbackShowcaseModels(DateTime now) => [
        ModelPrice(id: 'deepseek-v4.1-flash', vendor: 'DeepSeek', pricePerMillion: 0.000072, channels: 220, updatedAt: now),
        ModelPrice(id: 'deepseek-v4.1-flash-1017', vendor: 'DeepSeek', pricePerMillion: 0.000180, channels: 212, updatedAt: now),
        ModelPrice(id: 'deepseek-v4-flash', vendor: 'DeepSeek', pricePerMillion: 0.000918, channels: 0, updatedAt: now),
        ModelPrice(id: 'glm-5.3-flash', vendor: 'Zhipu', pricePerMillion: 0.000006, channels: 183, updatedAt: now),
        ModelPrice(id: 'glm-5.3', vendor: 'Zhipu', pricePerMillion: 0.004200, channels: 0, updatedAt: now),
        ModelPrice(id: 'gpt-6-luna', vendor: 'OpenAI', pricePerMillion: 0.001102, channels: 459, updatedAt: now),
        ModelPrice(id: 'gpt-6.1-sol', vendor: 'OpenAI', pricePerMillion: 0.003000, channels: 886, updatedAt: now),
        ModelPrice(id: 'gpt-6.2-sol', vendor: 'OpenAI', pricePerMillion: 0.021100, channels: 220, updatedAt: now),
        ModelPrice(id: 'gpt-6-astra', vendor: 'OpenAI', pricePerMillion: 0.044000, channels: 0, updatedAt: now),
        ModelPrice(id: 'gpt-6.2-astra', vendor: 'OpenAI', pricePerMillion: 0.084000, channels: 0, updatedAt: now),
        ModelPrice(id: 'gpt-5.6-sol', vendor: 'OpenAI', pricePerMillion: 0.008798, channels: 0, updatedAt: now),
        ModelPrice(id: 'kimi-k3.1-pro', vendor: 'Moonshot', pricePerMillion: 0.000600, channels: 0, updatedAt: now),
      ];
}
