import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/model_price.dart';

class PriceHistoryService {
  static const _snapshotsKey = 'a6api_price_snapshots_v1';
  static const _maxSnapshots = 30;

  Future<List<PriceSnapshot>> loadSnapshots() async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_snapshotsKey) ?? [];
    return rawList
        .map((e) => PriceSnapshot.fromJson(jsonDecode(e) as Map<String, dynamic>))
        .toList();
  }

  /// 将最新价格与最近一次历史快照比对，并保存新快照
  Future<List<ModelPrice>> mergeWithHistoryAndSave(
    List<ModelPrice> currentModels,
  ) async {
    final snapshots = await loadSnapshots();
    final previousMap = snapshots.isNotEmpty ? snapshots.last.prices : <String, double>{};

    final merged = currentModels.map((m) {
      return m.copyWith(previousPrice: previousMap[m.id]);
    }).toList();

    final newMap = <String, double>{
      for (final m in currentModels) m.id: m.pricePerMillion,
    };

    // 仅当存在数据时记录快照
    if (newMap.isNotEmpty) {
      final updated = [
        ...snapshots,
        PriceSnapshot(timestamp: DateTime.now(), prices: newMap),
      ];
      final trimmed = updated.length > _maxSnapshots
          ? updated.sublist(updated.length - _maxSnapshots)
          : updated;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
        _snapshotsKey,
        trimmed.map((s) => jsonEncode(s.toJson())).toList(),
      );
    }

    return merged;
  }

  /// 获取某个模型的历史价格时间线
  Future<List<MapEntry<DateTime, double>>> getModelTimeline(String modelId) async {
    final snapshots = await loadSnapshots();
    final result = <MapEntry<DateTime, double>>[];
    for (final snap in snapshots) {
      final price = snap.prices[modelId];
      if (price != null) {
        result.add(MapEntry(snap.timestamp, price));
      }
    }
    return result;
  }
}
