import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/model_price.dart';
import '../services/price_history_service.dart';

class PriceMonitorPage extends StatefulWidget {
  final List<ModelPrice> models;
  final PriceHistoryService historyService;
  final Future<void> Function() onRefresh;
  final void Function(String modelId) onPreviewModel;

  const PriceMonitorPage({
    super.key,
    required this.models,
    required this.historyService,
    required this.onRefresh,
    required this.onPreviewModel,
  });

  @override
  State<PriceMonitorPage> createState() => _PriceMonitorPageState();
}

class _PriceMonitorPageState extends State<PriceMonitorPage> {
  String _searchQuery = '';
  String _selectedVendor = '全部';
  bool _onlyChanged = false;
  bool _refreshing = false;

  Future<void> _handleRefresh() async {
    setState(() => _refreshing = true);
    await widget.onRefresh();
    if (mounted) setState(() => _refreshing = false);
  }

  void _showHistorySheet(ModelPrice model) async {
    final timeline = await widget.historyService.getModelTimeline(model.id);
    if (!mounted) return;
    final fmt = DateFormat('MM-dd HH:mm');

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              model.id,
              style: Theme.of(ctx).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              '厂商: ${model.vendor} · 当前底价: \$${model.pricePerMillion.toStringAsFixed(6)} / 1M tokens',
              style: Theme.of(ctx).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            if (timeline.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('暂无历史快照，下拉刷新后将自动记录每次价格变化。'),
              )
            else
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: timeline.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, index) {
                    final entry = timeline[timeline.length - 1 - index];
                    return ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text('\$${entry.value.toStringAsFixed(6)} / 1M'),
                      trailing: Text(
                        fmt.format(entry.key),
                        style: Theme.of(ctx).textTheme.bodySmall,
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  widget.onPreviewModel(model.id);
                },
                icon: const Icon(Icons.play_arrow),
                label: const Text('在线预览该模型效果'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final vendors = <String>{
      '全部',
      ...widget.models.map((e) => e.vendor),
    }.toList();

    final filtered = widget.models.where((m) {
      if (_selectedVendor != '全部' && m.vendor != _selectedVendor) {
        return false;
      }
      if (_onlyChanged && !m.hasChanged) {
        return false;
      }
      if (_searchQuery.isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return m.id.toLowerCase().contains(q) ||
            m.vendor.toLowerCase().contains(q);
      }
      return true;
    }).toList();

    final changedCount = widget.models.where((m) => m.hasChanged).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('A6API 价格监控'),
        actions: [
          IconButton(
            onPressed: _refreshing ? null : _handleRefresh,
            icon: _refreshing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
            tooltip: '刷新价格并对比历史',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              decoration: InputDecoration(
                hintText: '搜索模型名称或厂商（如 gpt、deepseek、claude）',
                prefixIcon: const Icon(Icons.search),
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: (v) => setState(() => _searchQuery = v.trim()),
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                FilterChip(
                  label: Text('仅看变化 ($changedCount)'),
                  selected: _onlyChanged,
                  onSelected: (v) => setState(() => _onlyChanged = v),
                ),
                const SizedBox(width: 8),
                ...vendors.map(
                  (v) => Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(v),
                      selected: _selectedVendor == v,
                      onSelected: (_) => setState(() => _selectedVendor = v),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _handleRefresh,
              child: filtered.isEmpty
                  ? ListView(
                      children: const [
                        SizedBox(height: 120),
                        Center(child: Text('没有匹配的模型价格记录')),
                      ],
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                      itemCount: filtered.length,
                      itemBuilder: (ctx, i) {
                        final item = filtered[i];
                        return _ModelPriceCard(
                          model: item,
                          onTap: () => _showHistorySheet(item),
                          onPreview: () => widget.onPreviewModel(item.id),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModelPriceCard extends StatelessWidget {
  final ModelPrice model;
  final VoidCallback onTap;
  final VoidCallback onPreview;

  const _ModelPriceCard({
    required this.model,
    required this.onTap,
    required this.onPreview,
  });

  @override
  Widget build(BuildContext context) {
    final delta = model.priceDelta;
    final pct = model.changePercent;

    Widget badge;
    if (delta == null) {
      badge = _TagChip(text: '首次记录', color: Colors.grey.shade600);
    } else if (delta.abs() <= 1e-9) {
      badge = _TagChip(text: '价格持平', color: Colors.blueGrey);
    } else if (delta < 0) {
      final pctText = pct != null ? '${pct.toStringAsFixed(1)}%' : '降价';
      badge = _TagChip(text: '▼ $pctText', color: Colors.green.shade700);
    } else {
      final pctText = pct != null ? '+${pct.toStringAsFixed(1)}%' : '涨价';
      badge = _TagChip(text: '▲ $pctText', color: Colors.red.shade700);
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            model.id,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        badge,
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${model.vendor}'
                      '${model.channels > 0 ? ' · ${model.channels} 通道' : ''}'
                      ' · \$${model.pricePerMillion.toStringAsFixed(6)} / 1M',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: onPreview,
                icon: const Icon(Icons.play_circle_outline),
                tooltip: '在线预览效果',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TagChip extends StatelessWidget {
  final String text;
  final Color color;

  const _TagChip({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
