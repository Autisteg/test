import 'dart:async';
import 'package:flutter/material.dart';
import '../models/model_price.dart';
import '../services/a6api_service.dart';

class ModelPreviewPage extends StatefulWidget {
  final A6ApiService apiService;
  final List<String> models;
  final String? initialModel;
  final VoidCallback onNeedLogin;

  const ModelPreviewPage({
    super.key,
    required this.apiService,
    required this.models,
    this.initialModel,
    required this.onNeedLogin,
  });

  @override
  State<ModelPreviewPage> createState() => _ModelPreviewPageState();
}

class _ModelPreviewPageState extends State<ModelPreviewPage> {
  final TextEditingController _inputController = TextEditingController();
  final TextEditingController _systemController =
      TextEditingController(text: '你是一个简洁、准确的 AI 助手。');
  final ScrollController _scrollController = ScrollController();

  late String _selectedModel;
  double _temperature = 0.7;
  bool _showSettings = false;
  bool _isStreaming = false;
  final List<ChatMessage> _messages = [];
  StreamSubscription<({String delta, int? ttftMs, int? totalMs})>? _streamSub;

  @override
  void initState() {
    super.initState();
    _selectedModel = widget.initialModel ??
        (widget.models.isNotEmpty ? widget.models.first : 'gpt-6.1-sol');
  }

  @override
  void didUpdateWidget(covariant ModelPreviewPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialModel != null &&
        widget.initialModel != oldWidget.initialModel) {
      setState(() => _selectedModel = widget.initialModel!);
    }
  }

  @override
  void dispose() {
    _streamSub?.cancel();
    _inputController.dispose();
    _systemController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage() async {
    final text = _inputController.text.trim();
    if (text.isEmpty || _isStreaming) return;

    if (widget.apiService.apiKey.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('请先在「账号登录」页填写 A6API 的 API Key'),
          action: SnackBarAction(
            label: '去设置',
            onPressed: widget.onNeedLogin,
          ),
        ),
      );
      return;
    }

    _inputController.clear();
    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text));
      _messages.add(const ChatMessage(role: 'assistant', content: ''));
      _isStreaming = true;
    });
    _scrollToBottom();

    final assistantIndex = _messages.length - 1;
    final historyForRequest = _messages.sublist(0, assistantIndex);

    try {
      final stream = widget.apiService.streamChatPreview(
        model: _selectedModel,
        systemPrompt: _systemController.text,
        history: historyForRequest,
        temperature: _temperature,
      );

      await for (final chunk in stream) {
        if (!mounted) break;
        setState(() {
          final current = _messages[assistantIndex];
          _messages[assistantIndex] = current.copyWith(
            content: current.content + chunk.delta,
            ttftMs: chunk.ttftMs ?? current.ttftMs,
            totalMs: chunk.totalMs ?? current.totalMs,
          );
        });
        _scrollToBottom();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages[assistantIndex] = ChatMessage(
            role: 'assistant',
            content: '调用出错：$e',
            isError: true,
          );
        });
      }
    } finally {
      if (mounted) {
        setState(() => _isStreaming = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final modelOptions = {
      _selectedModel,
      ...widget.models,
    }.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('在线模型预览'),
        actions: [
          IconButton(
            onPressed: () => setState(() => _showSettings = !_showSettings),
            icon: Icon(_showSettings ? Icons.tune : Icons.tune_outlined),
            tooltip: '参数设置',
          ),
          IconButton(
            onPressed: _isStreaming
                ? null
                : () => setState(() => _messages.clear()),
            icon: const Icon(Icons.delete_outline),
            tooltip: '清空对话',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: DropdownButtonFormField<String>(
              value: _selectedModel,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: '当前预览模型',
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: modelOptions
                  .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                  .toList(),
              onChanged: _isStreaming
                  ? null
                  : (v) {
                      if (v != null) setState(() => _selectedModel = v);
                    },
            ),
          ),
          if (_showSettings)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: _systemController,
                        decoration: const InputDecoration(
                          labelText: 'System Prompt',
                          isDense: true,
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Text('Temperature: ${_temperature.toStringAsFixed(1)}'),
                          Expanded(
                            child: Slider(
                              value: _temperature,
                              min: 0.0,
                              max: 1.5,
                              divisions: 15,
                              onChanged: (v) => setState(() => _temperature = v),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          Expanded(
            child: _messages.isEmpty
                ? const Center(
                    child: Text(
                      '输入提示词即可实时预览模型回复效果与首字延迟 (TTFT)',
                      textAlign: TextAlign.center,
                    ),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (ctx, i) {
                      final msg = _messages[i];
                      final isUser = msg.role == 'user';
                      return Align(
                        alignment: isUser
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(ctx).size.width * 0.84,
                          ),
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: msg.isError
                                ? Theme.of(ctx).colorScheme.errorContainer
                                : isUser
                                    ? Theme.of(ctx).colorScheme.primaryContainer
                                    : Theme.of(ctx)
                                        .colorScheme
                                        .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SelectableText(
                                msg.content.isEmpty && _isStreaming
                                    ? '生成中...'
                                    : msg.content,
                              ),
                              if (!isUser &&
                                  (msg.ttftMs != null || msg.totalMs != null))
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Text(
                                    [
                                      if (msg.ttftMs != null)
                                        '首字: ${msg.ttftMs}ms',
                                      if (msg.totalMs != null)
                                        '总耗时: ${msg.totalMs}ms',
                                    ].join(' · '),
                                    style: Theme.of(ctx).textTheme.labelSmall,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputController,
                      minLines: 1,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: '输入测试内容...',
                        isDense: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _isStreaming ? null : _sendMessage,
                    icon: _isStreaming
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
