import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../services/a6api_service.dart';

class LoginPage extends StatefulWidget {
  final A6ApiService apiService;
  final Future<void> Function() onAuthChanged;

  const LoginPage({
    super.key,
    required this.apiService,
    required this.onAuthChanged,
  });

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late final TextEditingController _baseUrlController;
  late final TextEditingController _apiKeyController;
  final TextEditingController _accountController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _baseUrlController = TextEditingController(text: widget.apiService.baseUrl);
    _apiKeyController = TextEditingController(text: widget.apiService.apiKey);
    _accountController.text = widget.apiService.username;
  }

  @override
  void dispose() {
    _baseUrlController.dispose();
    _apiKeyController.dispose();
    _accountController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _saveApiConfig() async {
    setState(() => _loading = true);
    await widget.apiService.saveCredentials(
      newBaseUrl: _baseUrlController.text,
      newApiKey: _apiKeyController.text,
    );
    await widget.onAuthChanged();
    if (!mounted) return;
    setState(() => _loading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('API 配置已保存并刷新模型列表')),
    );
  }

  Future<void> _loginWithAccount() async {
    if (_accountController.text.trim().isEmpty ||
        _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入账号和密码')),
      );
      return;
    }

    setState(() => _loading = true);
    final res = await widget.apiService.loginWithPassword(
      account: _accountController.text,
      password: _passwordController.text,
    );
    if (res.ok) {
      await widget.onAuthChanged();
    }
    if (!mounted) return;
    setState(() => _loading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
  }

  Future<void> _openWebViewLogin() async {
    final cookie = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const _A6WebLoginScreen()),
    );
    if (cookie != null && cookie.isNotEmpty) {
      await widget.apiService.saveCredentials(newCookie: cookie);
      await widget.onAuthChanged();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已同步 a6api.vip 网页登录态')),
        );
      }
    }
  }

  Future<void> _logout() async {
    await widget.apiService.clearCredentials();
    _apiKeyController.clear();
    _passwordController.clear();
    await widget.onAuthChanged();
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已退出登录并清除本地凭证')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final loggedIn = widget.apiService.isLoggedIn;

    return Scaffold(
      appBar: AppBar(
        title: const Text('A6API 账号与密钥'),
        actions: [
          if (loggedIn)
            TextButton(
              onPressed: _logout,
              child: const Text('退出登录'),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: Icon(
                loggedIn ? Icons.verified_user : Icons.lock_outline,
                color: loggedIn ? Colors.green : Colors.orange,
              ),
              title: Text(loggedIn ? '已配置凭证' : '未登录 / 未配置 Key'),
              subtitle: Text(
                '站点: ${A6ApiService.defaultWebUrl}\n'
                '网关: ${widget.apiService.baseUrl}',
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            '方式一：网页登录 (推荐，支持验证码/OAuth)',
            style: Theme.of(context).textTheme.titleSmall,
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _loading ? null : _openWebViewLogin,
            icon: const Icon(Icons.public),
            label: const Text('打开 a6api.vip 内置网页登录'),
          ),
          const SizedBox(height: 20),
          Text(
            '方式二：API Key 配置 (用于在线预览模型效果)',
            style: Theme.of(context).textTheme.titleSmall,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _baseUrlController,
            decoration: const InputDecoration(
              labelText: 'Gateway Base URL',
              hintText: 'https://api.a6api.vip/v1',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _apiKeyController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'API Key (sk-...)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _loading ? null : _saveApiConfig,
            child: const Text('保存 API 配置并刷新模型'),
          ),
          const SizedBox(height: 20),
          Text(
            '方式三：账号密码直连登录',
            style: Theme.of(context).textTheme.titleSmall,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _accountController,
            decoration: const InputDecoration(
              labelText: '用户名 / 邮箱',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: '密码',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _loading ? null : _loginWithAccount,
            child: const Text('账号密码登录'),
          ),
        ],
      ),
    );
  }
}

class _A6WebLoginScreen extends StatefulWidget {
  const _A6WebLoginScreen();

  @override
  State<_A6WebLoginScreen> createState() => _A6WebLoginScreenState();
}

class _A6WebLoginScreenState extends State<_A6WebLoginScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(A6ApiService.defaultWebUrl));
  }

  Future<void> _syncAndClose() async {
    final raw = await _controller.runJavaScriptReturningResult('document.cookie');
    final cookie = raw.toString().replaceAll('"', '');
    if (mounted) {
      Navigator.pop(context, cookie);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('登录 a6api.vip'),
        actions: [
          TextButton(
            onPressed: _syncAndClose,
            child: const Text('完成登录'),
          ),
        ],
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}
