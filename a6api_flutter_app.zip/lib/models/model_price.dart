class ModelPrice {
  final String id;
  final String vendor;
  final double pricePerMillion; // USD per 1M tokens
  final int channels;
  final double? previousPrice;
  final DateTime updatedAt;

  const ModelPrice({
    required this.id,
    required this.vendor,
    required this.pricePerMillion,
    this.channels = 0,
    this.previousPrice,
    required this.updatedAt,
  });

  double? get priceDelta {
    if (previousPrice == null) return null;
    return pricePerMillion - previousPrice!;
  }

  double? get changePercent {
    if (previousPrice == null || previousPrice == 0) return null;
    return ((pricePerMillion - previousPrice!) / previousPrice!) * 100;
  }

  bool get hasChanged =>
      priceDelta != null && priceDelta!.abs() > 1e-9;

  ModelPrice copyWith({
    String? id,
    String? vendor,
    double? pricePerMillion,
    int? channels,
    double? previousPrice,
    DateTime? updatedAt,
  }) {
    return ModelPrice(
      id: id ?? this.id,
      vendor: vendor ?? this.vendor,
      pricePerMillion: pricePerMillion ?? this.pricePerMillion,
      channels: channels ?? this.channels,
      previousPrice: previousPrice ?? this.previousPrice,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'vendor': vendor,
        'pricePerMillion': pricePerMillion,
        'channels': channels,
        'previousPrice': previousPrice,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory ModelPrice.fromJson(Map<String, dynamic> json) => ModelPrice(
        id: json['id'] as String,
        vendor: (json['vendor'] as String?) ?? 'Unknown',
        pricePerMillion: (json['pricePerMillion'] as num).toDouble(),
        channels: (json['channels'] as int?) ?? 0,
        previousPrice: (json['previousPrice'] as num?)?.toDouble(),
        updatedAt: DateTime.tryParse((json['updatedAt'] as String?) ?? '') ??
            DateTime.now(),
      );
}

class PriceSnapshot {
  final DateTime timestamp;
  final Map<String, double> prices;

  const PriceSnapshot({
    required this.timestamp,
    required this.prices,
  });

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'prices': prices,
      };

  factory PriceSnapshot.fromJson(Map<String, dynamic> json) {
    final rawPrices = (json['prices'] as Map<String, dynamic>?) ?? {};
    return PriceSnapshot(
      timestamp: DateTime.tryParse((json['timestamp'] as String?) ?? '') ??
          DateTime.now(),
      prices: rawPrices.map((k, v) => MapEntry(k, (v as num).toDouble())),
    );
  }
}

class ChatMessage {
  final String role; // 'user' | 'assistant' | 'system'
  final String content;
  final int? ttftMs;
  final int? totalMs;
  final bool isError;

  const ChatMessage({
    required this.role,
    required this.content,
    this.ttftMs,
    this.totalMs,
    this.isError = false,
  });

  ChatMessage copyWith({
    String? content,
    int? ttftMs,
    int? totalMs,
    bool? isError,
  }) {
    return ChatMessage(
      role: role,
      content: content ?? this.content,
      ttftMs: ttftMs ?? this.ttftMs,
      totalMs: totalMs ?? this.totalMs,
      isError: isError ?? this.isError,
    );
  }
}
