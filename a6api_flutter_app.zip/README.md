# A6API 价格监控与模型预览 (Flutter)

面向 `https://a6api.vip` 与 `https://api.a6api.vip/v1` 编写的 Flutter 客户端源码，包含以下核心功能：

1. **价格变化监控 (`lib/pages/price_monitor_page.dart`)**：
   - 自动记录每次刷新时的模型价格快照（`SharedPreferences` 本地持久化），与历史快照对比并标注涨跌幅（降价绿色、涨价红色）。
   - 支持按厂商筛选、关键词搜索、“仅看变化”过滤，以及点击查看单模型历史价格时间线。
2. **在线模型预览 (`lib/pages/model_preview_page.dart`)**：
   - 基于 OpenAI 兼容网关 `https://api.a6api.vip/v1/chat/completions` 实现 SSE 流式输出。
   - 支持切换模型、配置 System Prompt 与 Temperature，并实时统计首字延迟（TTFT）与总耗时。
3. **多方式登录 (`lib/pages/login_page.dart`)**：
   - 内置 `WebView` 登录 `https://a6api.vip` 并同步 Cookie（兼容人机验证与第三方登录）。
   - 支持直接配置 API Key（`sk-...`）与账号密码直连登录。

## 本地运行步骤

1. 在本地环境安装 Flutter SDK（`>= 3.2.0`）。
2. 解压本项目并进入目录：
   ```bash
   flutter create . --platforms=android,ios
   flutter pub get
   flutter run
   ```
3. 如需打包 Android APK：
   ```bash
   flutter build apk --release
   ```
   > 注意：Android 端请确保 `android/app/src/main/AndroidManifest.xml` 中包含 `<uses-permission android:name="android.permission.INTERNET" />`（`flutter create` 默认已包含）。
